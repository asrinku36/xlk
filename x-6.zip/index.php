<?php  include 'lollipop.php'; ?>
<!doctype html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="keywords" content="">
    <meta name="author" content="">
    <link href="https://i.imgur.com/PDnhoUX.png" rel="icon" type="image/ico">
    <title><?php echo $title; ?> XXX Leaked Sex Videos Online</title>
    <meta name="description" content="<?php echo $title; ?> Leaked Full Video Watch Online & Free Download Online Without Buffering. Support Android, iPhone, iPad, Tablet." />
    <meta property="og:image" content="<?php echo $image; ?>" />
	  <meta property="og:title" content="<?php echo $title; ?> XXX Leaked Videos Online" />
		<meta property="og:description" content="<?php echo $title; ?> Leaked Full Video Watch Online & Free Download Online Without Buffering. Support Android, iPhone, iPad, Tablet." />
		<meta property="og:image:width" content="750" />
		<meta property="og:image:height" content="500" />
		<meta property="og:image:type" content="image/jpeg" />
		<meta name="twitter:card" content="summary_large_image" />
		<meta name="twitter:title" content="<?php echo $title; ?> XXX Leaked Videos Online" />
		<meta name="twitter:description" content="<?php echo $title; ?> Leaked Full Video Watch Online & Free Download Online Without Buffering. Support Android, iPhone, iPad, Tablet." />
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <script type='text/javascript' src='//tunefatigueclarify.com/37/1a/4c/371a4c2b1b326e28dcffba5436b5a897.js'></script>
    <script type='text/javascript' src='//tunefatigueclarify.com/32/e4/fa/32e4facb74cd819327adb206f199cda6.js'></script>
</head>

<body>
    <nav class="navbar navbar-expand-md navbar-dark bg-dark top_menu">
      <div class="container mobile_header">
        <a class="logo navbar-brand" href="https://disgustingmad.com/ftqsaxyn?key=c47fafc15932a5f7e42865f62204ef5c"><b>LEAKED SEX HD</B></a>
        <ul class="nav justify-content-end">
          <li class="dropdown">
              <a href="#" class="signin_btn"  role="button" aria-expanded="true"><i class="fa fa-user"></i> Login | </span></a>
              <a class="affiliate" href="https://disgustingmad.com/ftqsaxyn?key=c47fafc15932a5f7e42865f62204ef5c">Register</a>
          </li>
        </ul>
      </div>
    </nav>
   <div class="container">
      <div class="header"><br>
        <h2 class="text-center"><b style="color: White;"><?php echo $title; ?> Leaked Videos Online</h2>
        <div style="display: flex; justify-content: center;">
            <script type="text/javascript">
	atOptions = {
		'key' : '6dfce88924ade79d41dabc123ef50177',
		'format' : 'iframe',
		'height' : 90,
		'width' : 728,
		'params' : {}
	};
</script>
<script type="text/javascript" src="//tunefatigueclarify.com/6dfce88924ade79d41dabc123ef50177/invoke.js"></script>
        </div>
</div>
      <div class="video_section" id="video">


        <center><img class="img img-fluid" src="<?php echo $image; ?>" alt="Image"></center>



         <div class="video_player videoPlayerBtn">
	   <span id="play" class="play-btn-border ease"><i class="fa fa-play-circle headline-round ease" aria-hidden="true"></i></span>
          </div>
	  <div class="text-center videoLoading" style="display:none">
	    <span class="spinner loading"></span>
	  </div>
		 
		 <div class="controls">	
		 	<div class="controlContent">	 	 	
				<div id="leftControls" >
					<i class="fa fa-play controlBtn videoPlayerBtn" aria-hidden="true"></i> &nbsp;&nbsp;	
					<i class="fa fa-volume-up controlBtn" aria-hidden="true"></i>		
				</div>	
				<div id="rightControls">
					<span class="live-badge__icon"></span> WATCH &nbsp;&nbsp;	
					<i class="fa fa-cog"></i> &nbsp;&nbsp;
					<i class="fa fa-arrows icon-size-fullscreen"></i>	
				</div>	
			</div>		
		 </div>
		 
      </div>
      
	  <br />
	  
	  <div class="text-center">
		<a class="btn btn-outline affiliate" href="https://disgustingmad.com/ftqsaxyn?key=c47fafc15932a5f7e42865f62204ef5c">Watch Now</a>  <a class="btn btn-outline affiliate" href="https://disgustingmad.com/ftqsaxyn?key=c47fafc15932a5f7e42865f62204ef5c">DOWNLOAD FREE</a>
	  </div>
</br>	   

<div style="display: flex; justify-content: center;">
<script type="text/javascript">
	atOptions = {
		'key' : '46b05f4832675702f3d1cffe74d7035a',
		'format' : 'iframe',
		'height' : 60,
		'width' : 468,
		'params' : {}
	};
</script>
<script type="text/javascript" src="//tunefatigueclarify.com/46b05f4832675702f3d1cffe74d7035a/invoke.js"></script>
</div>
           <center> <div class="col-md-7">
			<div class="device-features__content text-left">
				<p class="sub_headline"><center>Watch <?php echo $title; ?> Leaked Videos Online & Free Download for FREE, TV Streaming, Online Streaming & Download from Anywhere at Anytime. Optimized for PC, Mac, iPad, iPhone, Android, PS4, Xbox One, and Smart TVs.<center></p>
    <div style="display: flex; justify-content: center;">
<script type="text/javascript">
	atOptions = {
		'key' : 'b9131bc9039134ba09a60659dbe40af1',
		'format' : 'iframe',
		'height' : 250,
		'width' : 300,
		'params' : {}
	};
</script>
<script type="text/javascript" src="//tunefatigueclarify.com/b9131bc9039134ba09a60659dbe40af1/invoke.js"></script>
</div>
				<center> <div class="device-features__brands">
					<img class="img-fluid" width="30" src="assets/img/channels/devices_pc.png" alt="All Devices">
					<img class="img-fluid" width="30" src="assets/img/channels/apple_pc.png" alt="iOS">
					<img class="img-fluid" width="30" src="assets/img/channels/android_pc.png" alt="Android">
					<img class="img-fluid" width="30" src="assets/img/channels/chromecast_pc.png" alt="Chromecast">
				</div> </center> </center>
				
				<!--<div class="row feature">
					<div class="col-md-3">
						<h6 class="list-group-item-heading"><i class="fa fa-film biru fa-fw"></i> High Quality Streaming</h6>
						<p class="feature_sub_title">All <?php echo $title; ?> leaked videos are available in the HD Quality or even higher!</p>
					</div>
					<div class="col-md-3">
						<h6 class="list-group-item-heading"><i class="fa fa-youtube-play pink fa-fw"></i> Watch Without Limits</h6>
						<p class="feature_sub_title">You will get access to all of your favourite The <?php echo $title; ?> leaked videos without any limits.</p>
					</div>
					<div class="col-md-3">
						<h6 class="list-group-item-heading"><i class="fa fa-ban coklat fa-fw"></i> No Ads, 100% Free Advertising</h6>
						<p class="feature_sub_title">Your account will always be free from all kinds of advertising.</p>
					</div>
					
					<div class="col-md-3">
						<h6 class="list-group-item-heading"><i class="fa fa-tablet ijo fa-fw"></i> Watch anytime, anywhere</h6>
						<p class="feature_sub_title">It works on your Mobile, TV, PC or MAC!</p>
					</div>
					
				</div>-->
				
				<center> <a href="https://disgustingmad.com/ftqsaxyn?key=c47fafc15932a5f7e42865f62204ef5c" class="btn btn-md btn-outline affiliate">Create A Free Account</a> </center><div></div>
<script type="text/javascript">
	atOptions = {
		'key' : '3e72d5e77802625826273c2346d8ed9c',
		'format' : 'iframe',
		'height' : 300,
		'width' : 160,
		'params' : {}
	};
</script>
<script type="text/javascript" src="//tunefatigueclarify.com/3e72d5e77802625826273c2346d8ed9c/invoke.js"></script>

<center><p>Discover the latest leaked videos at here. Our site offers a curated selection of exclusive content. Stay updated with the freshest and most exciting leaks, all in one place. Enjoy a seamless and secure browsing experience with us. Visit now and explore!</p></center>
</div>
				</div>
		</div>
	  </div>
  </div>
			   
  <footer class="footer">
      <div class="container">
      	<div class="row">
		  <div class="col-md-6 col-xs-12">
		  	<div class="copyright">Copyright @ <a href="#">leak.eneu.io</a> | All rights reserved</div>
		  </div>
		  <div class="col-md-6 col-xs-12">
			<div class="footer__links d-flex justify-content-end">
				<a href="dmca" data-page='dmca' data-title="DMCA" class="info">DMCA</a>
				<a href="privacy-policy" data-page='privacy'  data-title="Privacy Policy" class="info">Privacy Policy</a>
				<a href="contact-us" data-page='terms' data-title="Contact US" class="info">Contact US</a>
				
			</div>
		  </div>
		</div>
      </div>
    </footer>
	
	<div id="singin_panel">
		<div class="signin__close">
		<i class="fa fa-close fa-lg" aria-hidden="true"></i>
		</div>
		
		<div class="signin__holder">
			<form id="signinform">
				<div class="signin__default">
					<h1>Sign In</h1>
					<div class="signin__group">
						<label for="email" class="">Email</label>
						<input type="text" id="email" placeholder="Enter your email">
					</div>
					<div class="signin__group">
						<label for="password" class="">Password</label>
						<span class="label-note" id="forgotpass">Forgot Password?</span>
						<input type="password" id="password" placeholder="Enter your password">
					</div>
					<div class="form-alert" style="display: none;">Oops! Your Password or email address Doesn't Match!</div>
					<button class="btn btn-outline btn-md mt-3 singin_btn" type="submit">Sign In</button>
					<div class="signin__footer">
						<a href="https://disgustingmad.com/ftqsaxyn?key=c47fafc15932a5f7e42865f62204ef5c" class="affiliate" >Don't have an account? <span>Sign Up</span></a>
					</div>
				</div>
			</form>
			
			<form id="resetpassform">
				<div class="signin__resetpassword" style="display: none;">
					<h1>Reset Password</h1>
					<p class="text-muted">Enter your email address and we'll send you a link to reset your password.</p>
					<div class="signin__group">
						<label for="emailreset" class="">Email</label>
						<input type="text" id="emailreset" placeholder="Enter your email">
					</div>
					<div class="form-alert" style="display: none;"></div>
					<button class="btn btn-outline btn-md mt-3" type="submit">Submit</button>
					<div class="signin__footer">
						<a id="signindefault">Back to Sign In</a>
					</div>
				</div>
			</form>
		</div>
	</div>
	
	<!-- Modal -->
<div class="modal fade" id="video_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header modal_header_info">
        <h6 class="modal-title text-center" id="exampleModalLabel">Please Sign Up to Watch <?php echo $title; ?> Leaked Videos & Download Online For Free</h6>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="row">
			<div class="col-md-6">
			<!--<div><img class="img-fluid" src="<?php echo $image; ?>" alt="image"></div>-->
<div style="display: flex; justify-content: center;">
<script type="text/javascript">
	atOptions = {
		'key' : 'b9131bc9039134ba09a60659dbe40af1',
		'format' : 'iframe',
		'height' : 250,
		'width' : 300,
		'params' : {}
	};
</script>
<script type="text/javascript" src="//tunefatigueclarify.com/b9131bc9039134ba09a60659dbe40af1/invoke.js"></script>
</div>
		   
				<h5>Member Login</h5>
				<div class="form-group">
					<input type="text" class="form-control input-sm" id="userid" placeholder="username">
				</div>
				<div class="form-group">
					<input type="password" class="form-control input-sm" id="password" placeholder="password">
				</div>
				<p class="msg">
				</p>
				<input type="button" id="modal_login_btn" class="btn btn-primary" value="Log in">
				<a class="affiliate btn btn-block btn-success" href="https://disgustingmad.com/ftqsaxyn?key=c47fafc15932a5f7e42865f62204ef5c" target=""> Sign Up For Free!</a>
			</div>
			<div class="col-md-6">
				<div class="list-group">
					<div class="list-group-item modal-list">
						<h6 class="list-group-item-heading"><i class="fa fa-film biru fa-fw"></i> High Quality Streaming</h6>
						<p class="list-group-item-text">All <?php echo $title; ?> leaked videos are available in the HD Quality or even higher!</p>
					</div>
					<div class="list-group-item modal-list">
						<h6 class="list-group-item-heading"><i class="fa fa-youtube-play pink fa-fw"></i> Watch Without Limits</h6>
						<p class="list-group-item-text">You will get access to all <?php echo $title; ?> videos without any limits.</p>
					</div>
					<div class="list-group-item modal-list">
						<h6 class="list-group-item-heading"><i class="fa fa-ban coklat fa-fw"></i> No Ads, 100% Free Advertising</h6>
						<p class="list-group-item-text">Your account will always be free from all kinds of advertising.</p>
					</div>
					<div class="list-group-item modal-list">
						<h6 class="list-group-item-heading"><i class="fa fa-tablet ijo fa-fw"></i> Watch anytime, anywhere</h6>
						<p class="list-group-item-text">It works on your Mobile, TV, PC or MAC!</p>
					</div>                   
				</div>
			</div>
		</div>
      </div>
	  
    </div>
  </div>
</div>


<div class="modal fade" id="page_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="info_page_title"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      </div>
      <div class="modal-footer">
        
      </div>
    </div>
  </div>
</div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="assets/js/vendor/jquery-slim.min.html"><\/script>')</script>
    
    <script src="assets/js/bootstrap.min.js"></script>
  </body>


</html>

<script type="text/javascript">
$(function(){
	  $('.signin_btn').on('click', function(e){
	  		e.preventDefault();
	  		$('#singin_panel').addClass('open');
	  });
	  
	  $('.signin__close').on('click', function(e){
	  	e.preventDefault();
	  	$('#singin_panel').removeClass('open');
	  });
	  
	  $('#forgotpass').on('click', function(e){
	  	e.preventDefault();
	  	$('.signin__default').hide();
		$('.signin__resetpassword').show();
	  });
	  
	  $('#signindefault').on('click', function(e) {
	  	e.preventDefault();
	  	$('.signin__default').show();
		$('.signin__resetpassword').hide();
	  });
	  $('.singin_btn').on('click', function(e) {
	  	e.preventDefault();
	  	$('.form-alert').show();
		$('#email').addClass('invalid');
	  });
	  
	  $('.login_btn').on('click', function(e){
	  	e.preventDefault();
	  	$('.login_refresh').show();
		$('.login_btn').hide();
		$('.loginError').hide();
	  	setTimeout(function(){
			$('.memberLogin').hide();
			$('.login_refresh').hide();
			$('.loginError').show();
			$('.login_btn').show();
		},2000);
	  });
	  
	  $('#modal_login_btn').on('click', function(e){
	  	e.preventDefault();
	  	str ="<span class='badge badge-info'>Please wait...</span>";
	  	$('.msg').html(str);
		$('.msg').addClass("");
	  	setTimeout(function(){
			str ="<span class='badge badge-warning'>Wrong Username or Password</span>";
	  		$('.msg').html(str);
		},2000);
	  });
	  
	
	  $('.videoPlayerBtn').on('click', function(e){
	  	e.preventDefault();
		let url=$(this).attr('data-url');
		$('.video_player').hide();
		$('.videoLoading').show();
	
		setTimeout(function(){ 
		 // window.location.href=url;
		 $('#video_modal').modal('show');
		}, 2000);
	  });
	  
	  $('#video_modal').on('hidden.bs.modal', function (e) {
	  		e.preventDefault();
	  		$('.videoLoading').hide();
			$('.video_player').show();
		});
	  
	  $('.info').on('click', function(e){
		 e.preventDefault();
		 var page = $(this).attr('data-page');
		 page = page+'.php'
		 page_title = $(this).attr('data-title');
		 //$("#page_modal").load("fffffffffffffffffffffffffffffffff");
		 $('#page_modal').find('.modal-body').load(page, function(data){
		 	$('#info_page_title').text(page_title);
			$('#page_modal').modal('show');
		 });
		 //alert(page);
	  });
	  
	  $(document).on('click', '.icon-size-fullscreen', function (e) {
		e.preventDefault();
		launchIntoFullscreen(document.getElementById("video"));
		});
		
		$(document).on('click', '.icon-size-actual', function (e) {
			e.preventDefault();
			exitFullscreen();
		});
	  
	  
  
  });
  
	  function launchIntoFullscreen(element) {
		if(element.requestFullscreen) {
			element.requestFullscreen();
		} else if(element.mozRequestFullScreen) {
			element.mozRequestFullScreen();
		} else if(element.webkitRequestFullscreen) {
			element.webkitRequestFullscreen();
		} else if(element.msRequestFullscreen) {
			element.msRequestFullscreen();
		}
		$(".icon-size-fullscreen").removeClass("icon-size-fullscreen").addClass("icon-size-actual");
	}
	function exitFullscreen() {
		if(document.exitFullscreen) {
			document.exitFullscreen();
		} else if(document.mozCancelFullScreen) {
			document.mozCancelFullScreen();
		} else if(document.webkitExitFullscreen) {
			document.webkitExitFullscreen();
		}
		$(".icon-size-actual").removeClass("icon-size-actual").addClass("icon-size-fullscreen");
	}
	$(document).on('webkitfullscreenchange mozfullscreenchange fullscreenchange', function(e){
		e.preventDefault();
		var fullScreen = document.fullscreenElement || document.mozFullScreenElement || document.webkitFullscreenElement || document.msFullscreenElement ? true : false;
		if ( fullScreen ) {
			$(".icon-size-fullscreen").removeClass("icon-size-fullscreen").addClass("icon-size-actual");
		} else {
			$(".icon-size-actual").removeClass("icon-size-actual").addClass("icon-size-fullscreen");
		}
	});


</script>

   <!-- Histats.com  START  (aync)-->
<script type="text/javascript">var _Hasync= _Hasync|| [];
_Hasync.push(['Histats.start', '1,4809902,4,0,0,0,00010000']);
_Hasync.push(['Histats.fasi', '1']);
_Hasync.push(['Histats.track_hits', '']);
(function() {
var hs = document.createElement('script'); hs.type = 'text/javascript'; hs.async = true;
hs.src = ('//s10.histats.com/js15_as.js');
(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(hs);
})();</script>
<noscript><a href="/" target="_blank"><img  src="//sstatic1.histats.com/0.gif?4809902&101" alt="" border="0"></a></noscript>
<!-- Histats.com  END  -->